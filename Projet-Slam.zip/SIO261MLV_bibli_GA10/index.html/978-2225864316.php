<?php
require 'header.php';
?>
        <section class="book-detail">
            <img src="../Images/978-2225864316.jpg" alt="Couverture de Théogonie"  class="same-size">
            <h2>Théogonie</h2>
            <p><strong>Auteur :</strong> Hésiode</p>
            <p><strong>ISBN :</strong> 978-2225864316</p>
            <p><strong>Date de publication :</strong> Vers 700 av. J.-C.</p>
            <p><strong>Éditeur :</strong> Non spécifié</p>
            <p><strong>Genre :</strong> Poésie épique</p>
            <p><strong>Langue :</strong> Grec ancien (traduction française)</p>
            <p><strong>Résumé :</strong> La Théogonie est un poème épique d'Hésiode qui raconte la naissance et l’histoire des dieux grecs.</p>
            <a href="commande.php" class="buy-button">Acheter</a>
        </section>
        <section id="section3">
            <h2>Commentaires des utilisateurs</h2>
            <div class="comments-container">
                <div class="comment">
                    <div class="comment-content">
                        <p>"Une incroyable collection de mythes grecs !"</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"J'ai adoré la section sur Homère et Hésiode."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un trésor pour les passionnés de mythologie."</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Des livres rares et magnifiquement traduits."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un voyage fascinant dans l'Antiquité !"</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Idéal pour étudiants et amateurs d'histoire."</p>
                        <div class="stars">★★★☆☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Une belle introduction à la mythologie grecque."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un excellent recueil de récits antiques !"</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Les métamorphoses sont fascinantes et bien écrites."</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un peu lourd à lire, mais une lecture importante pour les passionnés."</p>
                        <div class="stars">★★★☆☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Une analyse enrichissante des mythes anciens."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Les commentaires sont utiles pour comprendre chaque récit."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un classique de la littérature grecque. Très complet !"</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Les illustrations ajoutent beaucoup à l'expérience de lecture."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un peu trop académique pour un lecteur casual."</p>
                        <div class="stars">★★☆☆☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Les récits sont intemporels et fascinants, bien que complexes."</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un excellent moyen de découvrir les bases de la mythologie."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"J'ai adoré la richesse des détails et des descriptions."</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Des livres essentiels pour tout étudiant en littérature classique."</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un peu de répétition, mais chaque récit vaut la peine d'être lu."</p>
                        <div class="stars">★★★★☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un peu déçu par la traduction, mais l'histoire reste captivante."</p>
                        <div class="stars">★★★☆☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Un regard intéressant sur la mythologie, mais parfois trop complexe."</p>
                        <div class="stars">★★★☆☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Une lecture passionnante et éducative !"</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"Difficile de suivre parfois, mais riche en contenu."</p>
                        <div class="stars">★★★☆☆</div>
                    </div>
                </div>
                <div class="comment">
                    <div class="comment-content">
                        <p>"J'ai appris énormément sur les dieux et héros grecs."</p>
                        <div class="stars">★★★★★</div>
                    </div>
                </div>
            </div>
        </section>
        <section id="section4">
            <h2>Contacts</h2>
            <p>
                Pour toute question, veuillez nous contacter à :
                <br>Email : <a href="p.martinslouro@ecole-ipssi.net">p.martinslouro@ecole-ipssi.net</a>
                <br>Téléphone : +33 1 23 45 67 89
            </p>
        </section>
    </main>
    <footer>
        <p>© 2024 Mythothèque Grecque - Tous droits réservés.</p>
    </footer>
</body>
</html>