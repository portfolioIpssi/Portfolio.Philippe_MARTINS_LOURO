
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mythothèque Grecque</title>
    <link rel="stylesheet" href="../style.css/Style.css">
</head>
<body>
    <header>
        <h1>Mythothèque Grecque</h1>
        <a href="index.php" id="logo">
            <img src="../Images/Logo_bibliotheque.png" alt="Logo de la Mythothèque Grecque">
        </a>
    </header>
    <nav>
        <a href="index.php#section1">Accueil</a>
        <a href="index.php#section2">Liste des livres</a>
        <a href="index.php#section3">Commentaires</a>
        <a href="index.php#section4">Contacts</a>
    </nav>
