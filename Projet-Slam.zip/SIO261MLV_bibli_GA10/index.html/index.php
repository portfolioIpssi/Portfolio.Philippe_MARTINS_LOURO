<?php
require 'head.php';
?>
    <main>

        <section id="section1">
            <h2>Bienvenue</h2>
            <p>
                La Mythothèque Grecque est un centre dédié à la préservation et à la diffusion de la mythologie grecque.
                Fondée en 1996, notre bibliothèque regroupe une collection unique de textes anciens, traductions modernes
                et documents visuels. Explorez nos livres, participez à nos conférences et découvrez un monde riche en histoires mythologiques.
            </p>
        </section>

        <section id="section2">
            <h2>Liste des livres</h2>
            <div class="book-card">
                <a href="978-2253004220.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253004220.jpg" alt="Couverture de L_Odyssee_par_Homere" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2253002202.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253002202.jpg" alt="Couverture de L'Iliade" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                    <a href="978-2225864316.php" title="Cliquez pour en savoir plus">
                        <img src="../Images/978-2225864316.jpg" alt="Couverture de Théogonie" style="max-width: 300px; border-radius: 10px;">
                    </a>
            </div>
            <div class="book-card">
                <a href="978-2253007214.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253007214.jpg" alt="Couverture des Métamorphoses" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2277292334.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2277292334.jpg" alt="Couverture des Argonautiques" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2253001366.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253001366.jpg" alt="Couverture de Œdipe Roi" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2253001489.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253001489.jpg" alt="Couverture de Médée" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2253001878.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253001878.jpg" alt="Couverture des Travaux et les Jours" style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2253002332.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253002332.jpg" alt="Couverture de Prométhée Enchaîné " style="max-width: 300px; border-radius: 10px;">
                </a>
            </div>
            <div class="book-card">
                <a href="978-2253001499.php" title="Cliquez pour en savoir plus">
                    <img src="../Images/978-2253001499.jpg" alt="Couverture les Bacchantes " style="max-width: 300px; border-radius: 10px;">
                </a>
                
            </div>
        </section>

        <?php
require 'footer.php';
?>